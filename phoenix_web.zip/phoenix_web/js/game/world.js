// Dựng hình bản đồ từ core/map.js: mặt đất, đường, công trình, rừng, bóng đổ, bầu trời, đèn.
// Mọi thứ nằm trong `root` dùng hệ trục của luật chơi (z hướng về bắc); root lật trục z cho khớp với Three.js.
// Gần như toàn bộ công trình được gộp vào vài lưới lớn nên điện thoại vẽ rất nhẹ.
import { config } from "../config.js";
import { Rng } from "../core/rng.js";
import * as meshes from "./meshes.js";

const T = window.THREE;
const { Builder, hexRgb, boxTris } = meshes;
const C = Object.fromEntries(Object.entries({
  steel: "#93a3a6", steelDark: "#6f7f85", base: "#5b6468", concrete: "#bdb7a8", slab: "#a9a495", rail: "#e0a91f",
  roof: "#7a4f3c", beam: "#4f5a63", wood: "#b98545", woodDark: "#8a5f2c", plank: "#7b858d", post: "#49535c",
  ramp: "#818b93", hazard: "#e98a1c", cab: "#b53b2d", glass: "#27323c", trailer: "#d7d6cf", tyre: "#1d1e21",
  asphalt: "#43464b", paint: "#ddd6bd", gravel: "#9a9482", tank: "#d9dbd6", band: "#c9482f", lamp: "#3b434b",
}).map(([k, v]) => [k, hexRgb(v)]));
const shadeOf = (rgb, k) => rgb.map((v) => v * k);

function glowTexture(inner, outer) {
  const c = document.createElement("canvas");
  c.width = c.height = 128;
  const g = c.getContext("2d"), grad = g.createRadialGradient(64, 64, 0, 64, 64, 64);
  grad.addColorStop(0, inner); grad.addColorStop(0.35, outer); grad.addColorStop(1, "rgba(0,0,0,0)");
  g.fillStyle = grad; g.fillRect(0, 0, 128, 128);
  return new T.CanvasTexture(c);
}

export class World {
  constructor(scene, map) {
    this.map = map;
    this.seed = map.seed;
    this.col = map.col;
    this.root = new T.Group();
    this.root.scale.z = -1;
    scene.add(this.root);
    scene.background = new T.Color(config.SKY_MID);
    scene.fog = new T.Fog(config.FOG[0], config.FOG[1], config.FOG[2]);
    const rng = new Rng(map.seed + 1);

    this._sky(rng);
    this._ground(rng);
    this._decals(rng);
    this._shadows();
    this._structures(rng);
    this._props();
    this._lamps();
  }

  _mesh(geometry, material = meshes.SHARED, order = 0) {
    const mesh = new T.Mesh(geometry, material);
    mesh.matrixAutoUpdate = false;
    mesh.renderOrder = order;
    this.root.add(mesh);
    return mesh;
  }

  // ---------- bầu trời: vòm chuyển màu + mặt trời thấp + dãy núi ----------
  _sky(rng) {
    const geo = new T.SphereGeometry(320, 24, 12), pos = geo.attributes.position, colors = [];
    const top = hexRgb(config.SKY_TOP), mid = hexRgb(config.SKY_MID), low = hexRgb(config.SKY_HORIZON);
    for (let i = 0; i < pos.count; i++) {
      const h = Math.max(0, pos.getY(i) / 320), a = h < 0.25 ? low : mid, b = h < 0.25 ? mid : top, t = h < 0.25 ? h / 0.25 : (h - 0.25) / 0.75;
      colors.push(a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t);
    }
    geo.setAttribute("color", new T.Float32BufferAttribute(colors, 3));
    const dome = this._mesh(geo, new T.MeshBasicMaterial({ vertexColors: true, side: T.BackSide, fog: false, depthWrite: false }), -10);
    dome.frustumCulled = false;
    const sun = new T.Sprite(new T.SpriteMaterial({ map: glowTexture("rgba(255,250,235,1)", "rgba(255,214,150,0.55)"), fog: false,
      blending: T.AdditiveBlending, depthWrite: false }));
    sun.position.set(meshes.SUN[0] * 280, meshes.SUN[1] * 280, meshes.SUN[2] * 280);
    sun.scale.setScalar(150);
    this.root.add(sun);

    const far = new T.MeshBasicMaterial({ vertexColors: true, side: T.DoubleSide });   // núi chìm một phần trong sương cho có chiều sâu
    for (let i = 0; i < 26; i++) {
      const angle = (i * Math.PI * 2) / 26 + rng.uniform(-0.08, 0.08), dist = rng.uniform(76, 104);
      const m = new T.Mesh(meshes.mountainGeometry(rng), far);
      m.position.set(Math.cos(angle) * dist, -1, Math.sin(angle) * dist);
      m.scale.set(rng.uniform(18, 30), rng.uniform(24, 50), rng.uniform(18, 30));
      m.matrixAutoUpdate = false; m.updateMatrix();
      this.root.add(m);
    }
  }

  // ---------- mặt đất: cỏ ngoài rừng, sỏi trong các khu công trình ----------
  _ground(rng) {
    const b = new Builder(), size = 280, cells = 70, step = size / cells, grass = hexRgb("#6aa24a"), light = [0.98, 0.93, 0.80];
    const gravel = (x, z) => this.map.zones.some((q) => x > q.x0 - 1.5 && x < q.x1 + 1.5 && z > q.z0 - 1.5 && z < q.z1 + 1.5)
      || (Math.abs(x) < 9 && Math.abs(z) < 30) || (Math.abs(z) < 9 && Math.abs(x) < 30);
    for (let i = 0; i < cells; i++) {
      for (let j = 0; j < cells; j++) {
        const x0 = -size / 2 + i * step, z0 = -size / 2 + j * step;
        const p = [[x0, 0, z0], [x0 + step, 0, z0], [x0 + step, 0, z0 + step], [x0, 0, z0 + step]];
        for (const tri of [[p[0], p[1], p[2]], [p[0], p[2], p[3]]]) {
          const cx = (tri[0][0] + tri[1][0] + tri[2][0]) / 3, cz = (tri[0][2] + tri[1][2] + tri[2][2]) / 3;
          const base = gravel(cx, cz) ? C.gravel : grass, k = rng.uniform(0.9, 1.06);
          b.raw(tri, [base[0] * k * light[0], base[1] * k * light[1], base[2] * k * light[2]]);
        }
      }
    }
    this._mesh(b.geometry());
  }

  // ---------- đường nhựa, vạch kẻ, nền nhà kho ----------
  _decals(rng) {
    const b = new Builder();
    const quad = (x0, z0, x1, z1, rgb, y = 0.02) => { const p = [[x0, y, z0], [x1, y, z0], [x1, y, z1], [x0, y, z1]];
      b.raw([p[0], p[1], p[2]], rgb); b.raw([p[0], p[2], p[3]], rgb); };
    for (const r of this.map.roads) {
      const alongX = r.x1 - r.x0 > r.z1 - r.z0, len = alongX ? r.x1 - r.x0 : r.z1 - r.z0;
      for (let s = 0; s < len; s += 4) {                                  // từng tấm nhựa đậm nhạt khác nhau
        const k = rng.uniform(0.9, 1.08), rgb = shadeOf(C.asphalt, k);
        if (alongX) quad(r.x0 + s, r.z0, Math.min(r.x1, r.x0 + s + 4), r.z1, rgb); else quad(r.x0, r.z0 + s, r.x1, Math.min(r.z1, r.z0 + s + 4), rgb);
      }
      for (let s = 5; s < len - 5; s += 5) {                              // vạch đứt giữa đường, bỏ đoạn ngã tư
        const at = (alongX ? r.x0 : r.z0) + s;
        if (Math.abs(at) < 6) continue;
        if (alongX) quad(at, -0.12, at + 2.2, 0.12, C.paint, 0.035); else quad(-0.12, at, 0.12, at + 2.2, C.paint, 0.035);
      }
    }
    for (let i = -3; i <= 3; i++) {                                       // vạch sang đường quanh ngã tư
      quad(i * 0.85 - 0.25, 4.2, i * 0.85 + 0.25, 6.0, C.paint, 0.035); quad(i * 0.85 - 0.25, -6.0, i * 0.85 + 0.25, -4.2, C.paint, 0.035);
      quad(4.2, i * 0.85 - 0.25, 6.0, i * 0.85 + 0.25, C.paint, 0.035); quad(-6.0, i * 0.85 - 0.25, -4.2, i * 0.85 + 0.25, C.paint, 0.035);
    }
    quad(8, 8, 28, 22, shadeOf(C.concrete, 0.62), 0.025);                 // nền bê tông nhà kho (tối vì trong nhà)
    quad(15.6, 5, 20.4, 8, shadeOf(C.concrete, 0.85), 0.025);             // thềm trước cửa
    quad(15.6, 8, 20.4, 8.25, C.hazard, 0.04);                            // vạch cảnh báo ngưỡng cửa
    this._mesh(b.geometry(), new T.MeshBasicMaterial({ vertexColors: true, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 }), 1);
  }

  // ---------- bóng đổ: mỗi khối/cây in một mảng tối xuống đất theo hướng nắng ----------
  _shadows() {
    const sx = -meshes.SUN[0] / meshes.SUN[1], sz = -meshes.SUN[2] / meshes.SUN[1], pos = [];
    const cast = (points) => {                                            // points: [x, y, z] các đỉnh của vật
      const h = meshes.hull(points.map(([x, y, z]) => [x + sx * y, z + sz * y]));
      for (let i = 1; i < h.length - 1; i++) pos.push(h[0][0], 0.05, h[0][1], h[i][0], 0.05, h[i][1], h[i + 1][0], 0.05, h[i + 1][1]);
    };
    for (const k of this.map.blocks) {
      if (k.kind === "rail" || k.kind === "beam") continue;
      const pts = [];
      for (const [x, z] of [[k.x0, k.z0], [k.x1, k.z0], [k.x1, k.z1], [k.x0, k.z1]]) pts.push([x, k.y0, z], [x, this.col.topAt(k, x, z), z]);
      cast(pts);
    }
    const ring = (x, z, r, y) => Array.from({ length: 8 }, (_, i) => [x + Math.cos(i * 0.785) * r, y, z + Math.sin(i * 0.785) * r]);
    for (const p of this.map.props) {
      if (p.kind === "tree") cast([...ring(p.x, p.z, 0.25, 0), ...ring(p.x, p.z, 1.7 * p.scale, 2.6 * p.scale), ...ring(p.x, p.z, 0.4 * p.scale, 5.6 * p.scale)]);
      else if (p.kind === "rock") cast([...ring(p.x, p.z, 0.9 * p.scale, 0), ...ring(p.x, p.z, 0.6 * p.scale, 0.9 * p.scale)]);
      else if (p.kind === "tank") cast([...ring(p.x, p.z, p.scale, 0), ...ring(p.x, p.z, p.scale, p.scale * 2)]);
      else cast([...ring(p.x, p.z, 0.6 * p.scale, 0), ...ring(p.x, p.z, 0.6 * p.scale, p.scale)]);
    }
    for (const [x, z] of this.map.lamps) cast([...ring(x, z, 0.1, 0), ...ring(x, z, 0.1, 5)]);
    const geo = new T.BufferGeometry();
    geo.setAttribute("position", new T.Float32BufferAttribute(pos, 3));
    this._mesh(geo, new T.MeshBasicMaterial({ color: 0x141a2c, transparent: true, opacity: 0.30, depthWrite: false,
      polygonOffset: true, polygonOffsetFactor: -4, polygonOffsetUnits: -4, side: T.DoubleSide }), 2);
  }

  // ---------- công trình: mỗi loại khối một kiểu dáng ----------
  _structures(rng) {
    const b = new Builder();
    for (const k of this.map.blocks) {
      const dim = k.indoor ? 0.72 : 1, { x0, z0, x1, z1, y0, y1 } = k, lenX = x1 - x0, lenZ = z1 - z0;
      if (k.kind === "wall") {                                            // tôn thép chia tấm, chân tường sẫm
        const alongX = lenX >= lenZ, len = alongX ? lenX : lenZ, n = Math.max(1, Math.round(len / 1.3));
        for (let i = 0; i < n; i++) {
          const a = i / n, c = (i + 1) / n, rgb = shadeOf(i % 2 ? C.steel : C.steelDark, rng.uniform(0.95, 1.05));
          if (alongX) b.box(x0 + lenX * a, y0, z0, x0 + lenX * c, y1, z1, rgb); else b.box(x0, y0, z0 + lenZ * a, x1, y1, z0 + lenZ * c, rgb);
        }
        if (y0 === 0) b.box(x0 - 0.03, 0, z0 - 0.03, x1 + 0.03, 0.5, z1 + 0.03, C.base);
      } else if (k.kind === "container") {
        const rgb = hexRgb(k.tint), alongX = lenX >= lenZ, len = alongX ? lenX : lenZ;
        b.box(x0, y0, z0, x1, y1, z1, rgb);
        for (let s = 0.3; s < len - 0.1; s += 0.6) {                      // gân tôn
          const dark = shadeOf(rgb, 0.82);
          if (alongX) b.box(x0 + s, y0 + 0.12, z0 - 0.035, x0 + s + 0.18, y1 - 0.12, z1 + 0.035, dark);
          else b.box(x0 - 0.035, y0 + 0.12, z0 + s, x1 + 0.035, y1 - 0.12, z0 + s + 0.18, dark);
        }
        const frame = shadeOf(rgb, 0.6);                                  // khung thép hai đầu
        if (alongX) { b.box(x0 - 0.04, y0, z0 - 0.04, x0 + 0.12, y1, z1 + 0.04, frame); b.box(x1 - 0.12, y0, z0 - 0.04, x1 + 0.04, y1, z1 + 0.04, frame); }
        else { b.box(x0 - 0.04, y0, z0 - 0.04, x1 + 0.04, y1, z0 + 0.12, frame); b.box(x0 - 0.04, y0, z1 - 0.12, x1 + 0.04, y1, z1 + 0.04, frame); }
      } else if (k.kind === "crate") {
        const n = Math.round((y1 - y0) / 1.3);
        for (let i = 0; i < n; i++) {
          const a = y0 + i * 1.3, j = i ? 0.06 : 0;
          b.box(x0 + j, a, z0 + j, x1 - j, a + 1.3, z1 - j, C.wood, dim);
          b.box(x0 + j - 0.03, a + 0.95, z0 + j - 0.03, x1 - j + 0.03, a + 1.13, z1 - j + 0.03, C.woodDark, dim);
          b.box(x0 + j - 0.03, a + 0.17, z0 + j - 0.03, x1 - j + 0.03, a + 0.35, z1 - j + 0.03, C.woodDark, dim);
        }
      } else if (k.kind === "barrier") {                                  // rào bê tông có vạch cam
        b.box(x0, 0, z0, x1, 0.25, z1, shadeOf(C.concrete, 0.9));
        const ix = lenX > lenZ ? 0 : 0.1, iz = lenX > lenZ ? 0.1 : 0;
        b.box(x0 + ix, 0.25, z0 + iz, x1 - ix, y1, z1 - iz, C.concrete);
        b.box(x0 + ix - 0.01, 0.62, z0 + iz - 0.01, x1 - ix + 0.01, 0.8, z1 - iz + 0.01, C.hazard);
      } else if (k.kind === "ramp") {
        b.add(meshes.wedgeTris(x0, z0, x1, z1, k.ramp.low, y1, k.ramp.axis, k.ramp.dir), C.ramp, null, 1);
        const N = 9, alongX = k.ramp.axis === "x";                        // gờ chống trượt
        for (let i = 1; i < N; i++) {
          const t = i / N, at = alongX ? x0 + lenX * t : z0 + lenZ * t, h = this.col.topAt(k, alongX ? at : x0, alongX ? z0 : at);
          if (alongX) b.box(at - 0.05, h, z0 + 0.1, at + 0.05, h + 0.05, z1 - 0.1, C.rail); else b.box(x0 + 0.1, h, at - 0.05, x1 - 0.1, h + 0.05, at + 0.05, C.rail);
        }
      } else if (k.kind === "truck") {
        if (k.part === "cab") {
          b.box(x0, 0.5, z0, x1, y1, z1, C.cab);
          b.box(x0 - 0.02, 1.5, z0 + 0.15, x0 + 0.5, 2.35, z1 - 0.15, C.glass);
          b.box(x0 + 0.3, 0, z0 - 0.02, x0 + 1.3, 0.95, z1 + 0.02, C.tyre);
        } else if (k.part === "trailer") {
          b.box(x0, y0, z0, x1, y1, z1, C.trailer);
          b.box(x0, y0 - 0.12, z0 + 0.2, x1, y0, z1 - 0.2, C.post);
          b.box(x0 + 0.4, y0 + 0.5, z0 - 0.02, x1 - 0.4, y0 + 0.75, z1 + 0.02, C.band);
        } else b.box(x0, 0, z0 - 0.02, x1, y1, z1 + 0.02, C.tyre);
      } else {
        const rgb = { slab: C.slab, rail: C.rail, roof: C.roof, beam: C.beam, plank: C.plank, post: C.post }[k.kind] || C.concrete;
        b.box(x0, y0, z0, x1, y1, z1, rgb, dim);
        if (k.kind === "slab") b.box(x0 - 0.02, y1 - 0.08, z0 - 0.02, x1 + 0.02, y1 + 0.005, z1 + 0.02, shadeOf(C.slab, 1.1), dim);
      }
    }
    for (const p of this.map.props) {                                     // bồn chứa
      if (p.kind !== "tank") continue;
      b.add(meshes.cylTris(p.scale, p.scale * 2, 12, [p.x, 0, p.z]), C.tank);
      b.add(meshes.cylTris(p.scale * 1.02, 0.3, 12, [p.x, p.scale * 1.1, p.z]), C.band);
      b.add(meshes.cylTris(p.scale * 0.9, p.scale * 0.25, 12, [p.x, p.scale * 2, p.z], p.scale * 0.3), C.tank);
    }
    for (const [x, z] of this.map.lamps) {                                // cột đèn
      b.add(meshes.cylTris(0.11, 5, 6, [x, 0, z], 0.07), C.lamp);
      const tx = Math.abs(x) < Math.abs(z) ? -Math.sign(x) : 0, tz = tx ? 0 : -Math.sign(z);
      b.box(x + Math.min(0, tx * 1.2) - 0.05, 4.9, z + Math.min(0, tz * 1.2) - 0.05, x + Math.max(0, tx * 1.2) + 0.05, 5.0, z + Math.max(0, tz * 1.2) + 0.05, C.lamp);
    }
    this._mesh(b.geometry());
  }

  _props() {
    for (const p of this.map.props) {
      if (p.kind === "tank") continue;
      const look = new Rng(p.look);
      const [geometry, y] = p.kind === "tree" ? [meshes.treeGeometry(look), 0] : p.kind === "rock" ? [meshes.rockGeometry(look), p.scale * 0.3]
        : [meshes.crateGeometry(), p.scale / 2];
      const mesh = this._mesh(geometry);
      mesh.position.set(p.x, y, p.z);
      mesh.scale.setScalar(p.scale);
      mesh.rotation.y = (p.rotation * Math.PI) / 180;
      mesh.updateMatrix();
    }
  }

  // ---------- đèn: đầu đèn phát sáng + quầng sáng ấm in xuống mặt đường, đèn treo trong nhà kho ----------
  _lamps() {
    const glow = new T.SpriteMaterial({ map: glowTexture("rgba(255,236,190,1)", "rgba(255,190,90,0.45)"), blending: T.AdditiveBlending, depthWrite: false });
    const pool = new T.MeshBasicMaterial({ map: glowTexture("rgba(255,214,150,0.55)", "rgba(255,180,90,0.22)"), blending: T.AdditiveBlending,
      transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -6, polygonOffsetUnits: -6 });
    const disc = new T.PlaneGeometry(1, 1);
    disc.rotateX(-Math.PI / 2);
    const light = (x, y, z, size, floor = 0) => {
      const s = new T.Sprite(glow);
      s.position.set(x, y, z); s.scale.setScalar(size);
      this.root.add(s);
      const p = new T.Mesh(disc, pool);
      p.position.set(x, floor + 0.07, z); p.scale.setScalar(size * 4.2); p.renderOrder = 3;
      this.root.add(p);
    };
    for (const [x, z] of this.map.lamps) {
      const tx = Math.abs(x) < Math.abs(z) ? -Math.sign(x) : 0, tz = tx ? 0 : -Math.sign(z);
      light(x + tx * 1.2, 4.85, z + tz * 1.2, 2.0);
    }
    for (const [x, z] of [[13, 11.5], [23, 11.5]]) light(x, 5.5, z, 1.8);          // gian trước nhà kho
    for (const [x, z] of [[12, 19], [18, 19], [24, 19]]) { light(x, 2.8, z, 1.3); light(x, 5.8, z, 1.3, 3.25); }   // dưới và trên tầng lửng
  }
}
