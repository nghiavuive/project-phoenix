// Tạo lưới low-poly bằng code và tô bóng sẵn vào màu đỉnh (bản JS của phoenix/game/meshes.py).
// Bóng được "nướng" theo hướng nắng nên không cần đèn: nhẹ, chạy tốt trên điện thoại.
import { config } from "../config.js";

const T = window.THREE;
const TAU = Math.PI * 2;

const norm = (v) => { const l = Math.hypot(v[0], v[1], v[2]) || 1; return [v[0] / l, v[1] / l, v[2] / l]; };
export const SUN = norm(config.SUN);
const WARM = config.SUN_WARM, COOL = config.SHADE_COOL;

export const hexRgb = (code) => [1, 3, 5].map((i) => parseInt(code.slice(i, i + 2), 16) / 255);

/** Màu ánh sáng rọi lên một mặt: nền lạnh + nắng ấm theo góc + chút hắt sáng từ trời lên mặt ngửa. */
function light(tri, center) {
  const [a, b, c] = tri;
  const u = [b[0] - a[0], b[1] - a[1], b[2] - a[2]], v = [c[0] - a[0], c[1] - a[1], c[2] - a[2]];
  let n = norm([u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]]);
  const mid = [0, 1, 2].map((i) => (a[i] + b[i] + c[i]) / 3 - center[i]);
  if (n[0] * mid[0] + n[1] * mid[1] + n[2] * mid[2] < 0) n = [-n[0], -n[1], -n[2]];   // pháp tuyến hướng ra ngoài
  const sun = Math.max(0, n[0] * SUN[0] + n[1] * SUN[1] + n[2] * SUN[2]), sky = Math.max(0, n[1]) * 0.10;
  return [COOL[0] + WARM[0] * sun + sky, COOL[1] + WARM[1] * sun + sky, COOL[2] + WARM[2] * sun + sky];
}

/** Gom nhiều khối lồi thành một lưới duy nhất. */
export class Builder {
  constructor() { this.pos = []; this.col = []; }
  /** dim < 1 làm tối cả khối (đồ trong nhà, chỗ khuất). */
  add(tris, rgb = [1, 1, 1], center = null, dim = 1) {
    if (!center) {
      const pts = tris.flat();
      center = [0, 1, 2].map((i) => pts.reduce((s, p) => s + p[i], 0) / pts.length);
    }
    for (const tri of tris) {
      const l = light(tri, center);
      this.raw(tri, [Math.min(1, rgb[0] * l[0] * dim), Math.min(1, rgb[1] * l[1] * dim), Math.min(1, rgb[2] * l[2] * dim)]);
    }
    return this;
  }
  /** Hộp theo hai góc đối. */
  box(x0, y0, z0, x1, y1, z1, rgb, dim = 1) {
    return this.add(boxTris(x1 - x0, y1 - y0, z1 - z0, [(x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2]), rgb, null, dim);
  }
  raw(tri, rgb) {
    for (const p of tri) { this.pos.push(p[0], p[1], p[2]); this.col.push(rgb[0], rgb[1], rgb[2]); }
  }
  geometry() {
    const g = new T.BufferGeometry();
    g.setAttribute("position", new T.Float32BufferAttribute(this.pos, 3));
    g.setAttribute("color", new T.Float32BufferAttribute(this.col, 3));
    return g;
  }
}

/** Vật liệu không cần đèn, lấy màu đỉnh nhân với màu `tint` (để nháy trắng khi trúng đạn). */
export const paint = (tint = 0xffffff) => new T.MeshBasicMaterial({ vertexColors: true, side: T.DoubleSide, color: tint });
export const flat = (tint, opacity = 1) => new T.MeshBasicMaterial({ color: tint, side: T.DoubleSide,
  transparent: opacity < 1, opacity });
export const SHARED = paint();

// ---------- các khối cơ bản (trả về danh sách tam giác) ----------
export function boxTris(w = 1, h = 1, d = 1, at = [0, 0, 0]) {
  const [x0, x1, y0, y1, z0, z1] = [at[0] - w / 2, at[0] + w / 2, at[1] - h / 2, at[1] + h / 2, at[2] - d / 2, at[2] + d / 2];
  const p = [[x0, y0, z0], [x1, y0, z0], [x1, y1, z0], [x0, y1, z0], [x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1]];
  const quads = [[0, 1, 2, 3], [5, 4, 7, 6], [4, 0, 3, 7], [1, 5, 6, 2], [3, 2, 6, 7], [4, 5, 1, 0]];
  return quads.flatMap(([a, b, c, d2]) => [[p[a], p[b], p[c]], [p[a], p[c], p[d2]]]);
}

export function coneTris(radius = 1, height = 2, sides = 6, at = [0, 0, 0], twist = 0) {
  const tip = [at[0], at[1] + height, at[2]];
  const ring = Array.from({ length: sides }, (_, i) => [at[0] + Math.cos(twist + (i * TAU) / sides) * radius, at[1],
    at[2] + Math.sin(twist + (i * TAU) / sides) * radius]);
  const tris = ring.map((p, i) => [p, ring[(i + 1) % sides], tip]);
  for (let i = 1; i < sides - 1; i++) tris.push([ring[0], ring[i], ring[i + 1]]);
  return tris;
}

const PHI = (1 + Math.sqrt(5)) / 2;
const ICO_V = [[-1, PHI, 0], [1, PHI, 0], [-1, -PHI, 0], [1, -PHI, 0], [0, -1, PHI], [0, 1, PHI], [0, -1, -PHI],
  [0, 1, -PHI], [PHI, 0, -1], [PHI, 0, 1], [-PHI, 0, -1], [-PHI, 0, 1]].map(norm);
const ICO_F = [[0, 11, 5], [0, 5, 1], [0, 1, 7], [0, 7, 10], [0, 10, 11], [1, 5, 9], [5, 11, 4], [11, 10, 2],
  [10, 7, 6], [7, 1, 8], [3, 9, 4], [3, 4, 2], [3, 2, 6], [3, 6, 8], [3, 8, 9], [4, 9, 5], [2, 4, 11], [6, 2, 10],
  [8, 6, 7], [9, 8, 1]];

/** Khối 20 mặt; có rng thì méo ngẫu nhiên thành tảng đá. */
export function blobTris(radius = 1, rng = null, jitter = 0, squash = [1, 1, 1], at = [0, 0, 0]) {
  const verts = ICO_V.map((v) => {
    const k = radius * (1 + (rng ? rng.uniform(-jitter, jitter) : 0));
    return [at[0] + v[0] * k * squash[0], at[1] + v[1] * k * squash[1], at[2] + v[2] * k * squash[2]];
  });
  return ICO_F.map(([a, b, c]) => [verts[a], verts[b], verts[c]]);
}

// ---------- vật thể hoàn chỉnh ----------
export function treeGeometry(rng, b = new Builder()) {
  const trunkH = rng.uniform(2.4, 3.0);            // tán cây cao quá đầu người để không che mắt
  b.add(boxTris(0.45, trunkH, 0.45, [0, trunkH / 2, 0]), hexRgb("#6b4a2f"));
  const green = hexRgb(rng.choice(["#2f8f4a", "#3aa35a", "#257a52", "#4aa845"]));
  let y = trunkH * 0.9, r = rng.uniform(1.5, 2.1);
  for (let i = 0; i < 3; i++) {
    const h = r * 1.25;
    b.add(coneTris(r, h, 6, [0, y, 0], rng.uniform(0, 1)), green);
    y += h * 0.5; r *= 0.72;
  }
  return b.geometry();
}

export function rockGeometry(rng) {
  const grey = rng.uniform(0.50, 0.68);
  const tris = blobTris(1, rng, 0.22, [1, rng.uniform(0.6, 0.9), 1]);
  return new Builder().add(tris, [grey, grey * 0.98, grey * 0.94], [0, 0, 0]).geometry();
}

export function crateGeometry() {
  return new Builder().add(boxTris(1, 1, 1), hexRgb("#b98545"))
    .add(boxTris(1.06, 0.14, 1.06, [0, 0.36, 0]), hexRgb("#8a5f2c"))
    .add(boxTris(1.06, 0.14, 1.06, [0, -0.36, 0]), hexRgb("#8a5f2c")).geometry();
}

export function mountainGeometry(rng) {
  const b = new Builder(), twist = rng.uniform(0, 1);
  b.add(coneTris(1, 1, 7, [0, 0, 0], twist), hexRgb(rng.choice(["#6f8a8f", "#7b8f7a", "#64808c"])), [0, 0.3, 0]);
  b.add(coneTris(0.37, 0.35, 7, [0, 0.662, 0], twist).slice(0, 7), [0.97, 0.98, 1.0], [0, 0.3, 0]);   // chóp tuyết
  return b.geometry();
}

/** Mặt đất ghép từ nhiều tam giác xanh đậm nhạt khác nhau. */
export function groundGeometry(size, cells, rng) {
  const b = new Builder(), step = size / cells, base = hexRgb("#5aa64a");
  for (let i = 0; i < cells; i++) {
    for (let j = 0; j < cells; j++) {
      const x0 = -size / 2 + i * step, z0 = -size / 2 + j * step;
      const p = [[x0, 0, z0], [x0 + step, 0, z0], [x0 + step, 0, z0 + step], [x0, 0, z0 + step]];
      for (const tri of [[p[0], p[1], p[2]], [p[0], p[2], p[3]]]) {
        const k = rng.uniform(0.86, 1.06);
        b.raw(tri, [base[0] * k, base[1] * k, base[2] * k]);
      }
    }
  }
  return b.geometry();
}

/** Thân người khối hộp (chân, thân, tay) màu xám để nhân với màu của từng loại địch. */
export function bodyGeometry() {
  return new Builder()
    .add(boxTris(0.34, 0.75, 0.36, [-0.2, 0.375, 0]), [0.55, 0.55, 0.6])
    .add(boxTris(0.34, 0.75, 0.36, [0.2, 0.375, 0]), [0.55, 0.55, 0.6])
    .add(boxTris(0.85, 0.8, 0.5, [0, 1.15, 0]))
    .add(boxTris(0.24, 0.7, 0.26, [-0.56, 1.15, 0.05]), [0.8, 0.8, 0.8])
    .add(boxTris(0.24, 0.7, 0.26, [0.56, 1.15, 0.05]), [0.8, 0.8, 0.8]).geometry();
}

export const blobGeometry = () => new Builder().add(blobTris(0.5), [1, 1, 1], [0, 0, 0]).geometry();

export function gemGeometry() {
  const top = [0, 0.6, 0], bottom = [0, -0.6, 0];
  const ring = [0, 1, 2, 3].map((i) => [Math.cos((i * TAU) / 4) * 0.42, 0, Math.sin((i * TAU) / 4) * 0.42]);
  const tris = ring.flatMap((p, i) => [[p, ring[(i + 1) % 4], top], [p, ring[(i + 1) % 4], bottom]]);
  return new Builder().add(tris, [1, 1, 1], [0, 0, 0]).geometry();
}

export const UNIT_BOX = new T.BoxGeometry(1, 1, 1);

/** Lăng trụ tròn (trụ nhiều cạnh) đứng thẳng, đáy ở `at`. */
export function cylTris(radius, height, sides = 10, at = [0, 0, 0], topRadius = radius) {
  const ring = (r, y) => Array.from({ length: sides }, (_, i) => [at[0] + Math.cos((i * TAU) / sides) * r, y, at[2] + Math.sin((i * TAU) / sides) * r]);
  const lo = ring(radius, at[1]), hi = ring(topRadius, at[1] + height), tris = [];
  for (let i = 0; i < sides; i++) {
    const j = (i + 1) % sides;
    tris.push([lo[i], lo[j], hi[j]], [lo[i], hi[j], hi[i]]);
    if (i > 0 && i < sides - 1) tris.push([hi[0], hi[i], hi[i + 1]], [lo[0], lo[i], lo[i + 1]]);
  }
  return tris;
}

/** Khối dốc (nêm): mặt trên đi từ `low` lên `high` theo trục axis, dir = 1 là cao dần về phía toạ độ lớn. */
export function wedgeTris(x0, z0, x1, z1, low, high, axis, dir) {
  const h = (x, z) => { const t = axis === "x" ? (x - x0) / (x1 - x0) : (z - z0) / (z1 - z0); return low + (high - low) * (dir > 0 ? t : 1 - t); };
  const b = [[x0, 0, z0], [x1, 0, z0], [x1, 0, z1], [x0, 0, z1]], t = b.map(([x, , z]) => [x, Math.max(0.02, h(x, z)), z]);
  const tris = [[t[0], t[1], t[2]], [t[0], t[2], t[3]], [b[0], b[1], b[2]], [b[0], b[2], b[3]]];
  for (let i = 0; i < 4; i++) { const j = (i + 1) % 4; tris.push([b[i], b[j], t[j]], [b[i], t[j], t[i]]); }
  return tris;
}

/** Bao lồi 2D (thuật toán chuỗi đơn điệu) - dùng để vẽ bóng đổ. */
export function hull(points) {
  const p = [...points].sort((a, b) => a[0] - b[0] || a[1] - b[1]);
  const cross = (o, a, b) => (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
  const half = (list) => { const h = []; for (const q of list) { while (h.length >= 2 && cross(h[h.length - 2], h[h.length - 1], q) <= 0) h.pop(); h.push(q); } h.pop(); return h; };
  return [...half(p), ...half(p.reverse())];
}
