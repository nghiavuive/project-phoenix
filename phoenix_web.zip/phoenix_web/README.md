# Project Phoenix - bản web

Game bắn súng góc nhìn thứ nhất phong cách low-poly, chạy thẳng trong trình duyệt trên máy tính và điện thoại.

- **Chơi một máy:** Sinh tồn, Đoàn kết với 2 đồng đội máy, PvP với 3 đối thủ máy.
- **Phòng riêng qua mạng:** tạo phòng Đoàn kết hoặc PvP, đọc mã 4 số cho bạn bè, tối đa 6 người.
- **Bản đồ nhiều tầng**, 8 vũ khí + lựu đạn + bom khói, ngắm bắn, bắn tỉa có ống ngắm.

## Chạy game

Cần Node.js 18 trở lên.

```
npm install
npm start
```

Mở `http://localhost:8080`. Chương trình này làm hai việc cùng lúc: phát trang game và làm máy chủ phòng.

- **Chơi chung trong cùng wifi:** các máy khác mở `http://<địa chỉ IP của máy đang chạy>:8080` (ví dụ `http://192.168.1.107:8080`), vào **Phòng riêng**. Không cần đưa gì lên mạng.
- **Chỉ chơi một máy, không cần phòng:** có thể đăng riêng `index.html` + thư mục `js/` lên bất kỳ dịch vụ web tĩnh nào.

## Đưa lên Internet để chơi khác mạng

Cần một dịch vụ chạy được Node.js và cho kết nối WebSocket. Dưới đây là các bước với Render (render.com), gói miễn phí; tên nút trên trang của họ có thể khác đôi chút theo thời gian.

1. **Đưa mã lên GitHub.** Tạo tài khoản github.com, tạo một repository mới, rồi tải toàn bộ thư mục này lên (kéo thả vào trang "uploading an existing file" là được). **Không** tải thư mục `node_modules`.
2. **Tạo dịch vụ trên Render.** Đăng nhập render.com bằng tài khoản GitHub, chọn New, Web Service, chọn repository vừa tạo. Điền:
   - Runtime: `Node`
   - Build Command: `npm install`
   - Start Command: `npm start`
   - Instance Type: `Free`
3. **Chờ triển khai xong**, Render cấp một địa chỉ dạng `https://ten-thay-dat.onrender.com`. Đó là địa chỉ game: gửi cho bạn bè, ai cũng mở địa chỉ này.
4. **Chơi:** một người vào Phòng riêng, bấm Tạo phòng, đọc mã 4 số; những người khác vào Phòng riêng, nhập mã, bấm Vào phòng; chủ phòng bấm Bắt đầu.

File `render.yaml` kèm theo đã khai sẵn các thông số trên, Render có thể tự đọc.

**Giới hạn của gói miễn phí Render** (theo tài liệu của họ, xem tại https://render.com/docs/free vào thời điểm viết):
- Không ai dùng trong 15 phút thì dịch vụ ngủ; người đầu tiên mở lại phải chờ khoảng một phút. Đang có người chơi thì không ngủ.
- 750 giờ chạy miễn phí mỗi tháng cho cả tài khoản.

Dịch vụ khác (Railway, Fly.io, máy chủ thuê riêng...) cũng dùng được: chỉ cần chạy `npm install` rồi `npm start`, cổng lấy từ biến môi trường `PORT`.

**Nên biết:**
- Máy mỗi người tự báo "tôi đang đứng đâu" và "tôi bắn trúng ai"; máy chủ giữ máu, điểm, địch. Chơi mượt nhưng không chống gian lận, hợp với nhóm bạn, không hợp mở công khai.
- Ai có địa chỉ game đều tạo được phòng; muốn vào phòng người khác thì phải biết mã. Phòng trống quá một phút tự đóng. Trận đang đánh không nhận thêm người.
- Trang xuất bản trên Claude chặn kết nối ra ngoài, nên ở đó chỉ chơi được với máy.

## Điều khiển

| Việc | Máy tính | Điện thoại |
|---|---|---|
| Di chuyển | W A S D | Ngón trái: cần ảo |
| Nhìn | Chuột | Ngón phải: vuốt (hoặc kéo trên nút BẮN) |
| Bắn / đánh | Chuột trái | Nút BẮN; tự bắn khi tâm ngắm trúng địch |
| Ngắm | Giữ chuột phải (hoặc Ctrl trái, V) | Nút NGẮM (bấm bật, bấm lần nữa tắt) |
| Đổi vũ khí | Phím 1-8, Q, lăn chuột | Chạm vào ô trên thanh vũ khí, hoặc nút ĐỔI |
| Lựu đạn / Bom khói | G / F | Nút LỰU / KHÓI |
| Chạy | Shift | Đẩy cần ảo hết cỡ về trước |
| Nhảy / Nạp đạn | Space / R | Nút NHẢY / NẠP |
| Tạm dừng | Esc hoặc P | Nút II |

Game tự nhận ra màn hình cảm ứng; nút "Điều khiển" trong menu để đổi tay.

## Vũ khí

Có sẵn cả 8 món từ đầu trận; súng lục đạn vô hạn, các súng khác đạn có hạn và được thêm khi nhặt hộp đạn (viên vàng).
Ngắm thì đạn chụm hơn và giật ít hơn nhưng đi chậm; chạy, nhảy hoặc bắn liên tục thì đạn toè ra (tâm ngắm nở theo).

| Phím | Vũ khí | Sát thương | Nhịp | Băng / dự trữ | Dùng khi |
|---|---|---|---|---|---|
| 1 | Súng lục | 34 | 0,22 s | 12 / vô hạn | Hết đạn các súng khác |
| 2 | Súng trường AK | 25 | 0,11 s | 30 / 150 | Đa dụng |
| 3 | Tiểu liên SMG | 15 | 0,065 s | 35 / 140 | Xả đạn tầm gần |
| 4 | Shotgun | 14 x 8 viên | 0,75 s | 6 / 18 | Sát mặt |
| 5 | Bắn tỉa | 150 | 1,3 s | 5 / 10 | Tầm xa, trùm |
| 6 | Súng máy | 22 | 0,085 s | 80 / 80 | Giữ chốt, nạp rất lâu |
| 7 | Chảo | 90, quét góc 100° | 0,55 s | - | Cận chiến; **đỡ được đạn bắn từ phía trước** |
| 8 | Dao | 55, góc 60° | 0,28 s | - | Cận chiến nhanh |

- **Lựu đạn** (đầu trận có 2, tối đa 4): nổ sau 2,2 giây, bán kính 6,5 m, nảy khỏi vật cản. Đứng gần là mình cũng dính.
- **Bom khói** (đầu trận có 1, tối đa 3): toả khói 12 giây. Địch bị khói che sẽ mất dấu, xạ thủ ngừng bắn.
- Địch chết có thể rơi: máu (xanh lá), đạn (vàng), lựu đạn (cam), bom khói (xám).

Muốn chỉnh hay thêm vũ khí: `js/core/weapons.js` (thông số) và `MODELS` trong `js/game/arsenal.js` (hình). Thông số lựu đạn, khói ở cuối `js/config.js`.

## Bản đồ và địch

Bản đồ khai báo trong `js/core/map.js` bằng các lệnh `box(...)` và `ramp(...)`; mỗi khối vừa là tường vừa là sàn đứng được.

| Khu | Có gì |
|---|---|
| KHO HÀNG (đông bắc) | Nhà 20 x 14 m, cửa lớn phía nam, cửa nhỏ phía tây, cửa sổ bắn được; dốc lên tầng lửng 3,25 m |
| BÃI CONTAINER (tây nam) | 7 container, dốc lên nóc, hai nóc nối bằng sàn thép, một chồng đôi cao 5,2 m |
| THÁP CANH (tây bắc) | Sàn cao 3,6 m có mái và tường chắn, dốc lên từ phía đông |
| BÃI XE (đông nam) | Xe tải, bồn chứa, rào bê tông |
| NGÃ TƯ | Điểm xuất phát, rào bê tông thấp (nhảy lên được, bắn qua đầu được) |

Địch tự tìm đường: vòng qua tường, vào cửa, leo dốc lên chỗ người chơi đang đứng (`js/core/nav.js`, và các mốc `path` của từng sàn cao trong `map.js`).

| Địch | Dáng | Cách đánh |
|---|---|---|
| Lính | Giáp đỏ, mũ sắt kính vàng, dùi cui | Áp sát đánh |
| Chạy nhanh | Lom khom, hai lưỡi dao dài, một mắt xanh, gai lưng | Rất nhanh, máu ít |
| Xạ thủ | Cao gầy, áo choàng tím, súng trường dài | Giữ khoảng cách, bắn đạn bay chậm né được |
| Đồ tể | Vai rộng gấp đôi, giáp vạch vàng đen, nắm đấm khổng lồ | Rất trâu, không bị khựng khi trúng đạn |

Trúng đạn thì địch nháy sáng, giật người và khựng lại một nhịp; chết thì ngã ngửa rồi tan dần.

## Giữ gì, đổi gì so với bản Python

| Phần | Bản web |
|---|---|
| Luật đợt, điểm, chuỗi hạ gục, vật phẩm, 4 loại địch, luật Đoàn kết / PvP | Giữ nguyên |
| Con số cân bằng gốc | Giữ nguyên trong `js/config.js`, thêm các mục mới ở cuối file |
| Rừng thông, đá, thùng gỗ của bản đồ cũ | Giữ những cái không đè lên công trình mới |
| Cách tô bóng low-poly, xử lý cảm ứng, cách chia thư mục core / controls / game / ui | Giữ nguyên |
| Bản đồ | Mới: khu công nghiệp nhiều tầng, va chạm có độ cao, địch biết tìm đường |
| Vũ khí | Mới: 8 món, lựu đạn, bom khói, ngắm bắn, độ tản tăng khi bắn liên tục |
| Hình địch, mô hình súng, HUD, menu, âm thanh | Làm lại |
| Chơi với máy (bot) | Mới |
| Phòng riêng qua mạng | Có: máy chủ Node.js trong `server/`, dùng lại nguyên bộ luật `js/core/` |

## Cấu trúc

```
page.html                Nội dung trang (dùng để xuất bản); build.py tạo ra index.html hoàn chỉnh
index.html               Trang hoàn chỉnh để tự đăng
js/
  main.js                Điểm khởi động
  config.js              TẤT CẢ thông số cân bằng
  core/                  Luật chơi thuần logic - chạy được cả ngoài trình duyệt
    sim.js                 mô phỏng cả trận, 3 chế độ
    map.js                 bản đồ: công trình, sàn cao, khu vực
    collide.js             va chạm có độ cao (tường, sàn, dốc)
    nav.js                 tìm đường cho địch và bot
    bots.js                người chơi máy
    ballistics.js          đường đạn: trúng thân, trúng đầu, bị che
    weapons.js  enemies.js  waves.js  state.js  geometry.js  layout.js  layoutData.js  rng.js  storage.js
  controls/              intent.js  desktop.js  touch.js  pointers.js
  game/                  Dựng hình bằng Three.js - không chứa luật chơi
    app.js                 vòng lặp chính, chế độ, chuyển cảnh
    world.js  meshes.js    công trình, đường, bóng đổ, bầu trời, đèn
    actors.js              bộ khớp và thiết kế 4 loại địch, người chơi khác
    arsenal.js             mô hình súng, giật, nạp đạn, ngắm
    effects.js             vỏ đạn, vệt đạn, vụ nổ, toàn bộ âm thanh tổng hợp
    player.js  session.js
  net/session.js         phiên chơi qua mạng (cùng bộ thuộc tính với game/session.js)
  ui/                    hud.js  menus.js  touchOverlay.js
server/
  server.mjs             phát trang game + WebSocket tại /ws
  rooms.mjs              phòng: mã phòng, danh sách, chạy mô phỏng, phát trạng thái
tests/
  core.test.mjs          21 bài kiểm thử luật chơi  }
  net.test.mjs           6 bài kiểm thử máy chủ phòng } npm test
  online.test.mjs        máy chủ thật + hai trình duyệt: tạo phòng, vào bằng mã, đánh PvP và Đoàn kết
  browser.test.mjs       tự chơi cả 3 chế độ trong trình duyệt, máy tính + điện thoại đa chạm, chụp ảnh
  probe.mjs              công cụ chụp nhanh một cảnh để gỡ lỗi
```
